<?php

// define database connection
  define('DB_SERVER', 'localhost'); // eg, localhost - should not be empty for productive servers
  define('DB_SERVER_USERNAME', 'root');
  define('DB_SERVER_PASSWORD', '');
  define('DB_SERVER_PORT', '');		
  define('DB_DATABASE', 'itm');  	  
  