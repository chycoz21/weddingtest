<?php
      
    app_logs::http_log();
    
    app_logs::reset_log();

    app_session_close();

